﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Utworzenie obiektu Web Services
            GSMServiceAPI.GSMServicePortTypeClient ws = new GSMServiceAPI.GSMServicePortTypeClient();

           // Obiekt Account - zawiera login oraz haslo do konta API
            GSMServiceAPI.Account account = new GSMServiceAPI.Account();
            account.login = ""; // Login subkonta API
            account.pass = ""; // Hasło subkonta API

// Wysyłanie SMS:

            // Tablica obiektów Message - każdy element zawiera jedną wiadomość SMS, ktora ma zostać wyslana.
            GSMServiceAPI.Message[] messages = new GSMServiceAPI.Message[1]; 
            messages[0] = new GSMServiceAPI.Message();
            messages[0].recipients = new string[] {"48601234567"}; // Numery telefonów odbiorców danej wiadomości
            messages[0].message = "Tresc wiadomosci SMS"; // Tresc wiadomosci
            messages[0].sender = "BRAMKA SMS"; // Pole nadawcy, z ktorym ma zostac wyslany SMS (uprzednio zdefiniowane na koncie Uzytkownika)
            messages[0].msgType = 1; // Typ wiadomosci SMS: 1 - Tradycyjny SMS, 2 - Flash SMS, 3 - SMS ekonomiczny
            messages[0].unicode = false; // Czy wiadomosc ma byc wyslana w kodowaniu UNICODE?
            messages[0].sandbox = true; // Czy tryb testowy?

            // Wysyłanie SMS - wywolanie metody SendSMS
            GSMServiceAPI.SendSMSReturn[] sendResult = ws.SendSMS(account, messages);

            // Obsluga odpowiedzi z bramki SMS:
             Console.WriteLine("Status żądania: " + sendResult[0].status + ", Kod błędu: " + sendResult[0].errCode + ", Opis statusu: " + sendResult[0].description +
                          ", Nr odbiorcy: " + sendResult[0].recipient + ", ID wiadomości: " + sendResult[0].msgId + ", Liczba części: " + sendResult[0].parts + 
                          ", Koszt: " + sendResult[0].price + "\r\n");

            
// Sprawdzanie kosztu wiadomości
/*
            // Tablica obiektów Message - każdy element zawiera jedną wiadomość SMS, ktorej cena ma zostać sprawdzona.
            GSMServiceAPI.Message[] messages = new GSMServiceAPI.Message[1];
            messages[0] = new GSMServiceAPI.Message();
            messages[0].recipients = new string[] { "48601234567" }; // Numery telefonów odbiorców danej wiadomości
            messages[0].message = "Tresc wiadomosci SMS"; // Tresc wiadomosci
            messages[0].sender = "BRAMKA SMS"; // Pole nadawcy, z ktorym ma zostac wyslany SMS (uprzednio zdefiniowane na koncie Uzytkownika)
            messages[0].msgType = 1; // Typ wiadomosci SMS: 1 - Tradycyjny SMS, 2 - Flash SMS, 3 - SMS ekonomiczny
            messages[0].unicode = false; // Czy wiadomosc ma byc wyslana w kodowaniu UNICODE?

            // Sprawdzenie ceny wyslania SMS - wywolanie metody GetPrice
            GSMServiceAPI.GetPriceReturn[] getpriceResult = ws.GetPrice(account, messages);

            // Obsluga odpowiedzi z bramki SMS:
            Console.WriteLine("Status żądania: " + getpriceResult[0].status + ", Kod błędu: " + getpriceResult[0].errCode + ", Opis statusu: " + getpriceResult[0].description +
                          ", Nr odbiorcy: " + getpriceResult[0].recipient + ", Liczba części: " + getpriceResult[0].parts + ", Koszt: " + getpriceResult[0].price + "\r\n");
*/

// Sprawdzanie statusu wiadomości
/*
            // Tablica stringów - każdy element zawiera ID jednej wiadomości, której status ma zostać sprawdzony.
            string[] ids_status = new string[]{ "1234" }; 
           
            // Sprawdzenie aktualnego statusu wiadomości SMS - wywolanie metody GetStatus
            GSMServiceAPI.GetStatusReturn[] getstatusResult = ws.GetStatus(account, ids_status);

            // Obsluga odpowiedzi z bramki SMS:
            Console.WriteLine("Status żądania: " + getstatusResult[0].status + ", Kod błędu: " + getstatusResult[0].errCode + ", Opis statusu: " + getstatusResult[0].description +
                          ", ID wiadomości: " + getstatusResult[0].msgId + ", Nr odbiorcy: " + getstatusResult[0].recipient + ", Data wysyłki: " + getstatusResult[0].origDate +
                          ", Data ostatniej zmiany statusu: " + getstatusResult[0].doneDate + ", Status wiadomości: " + getstatusResult[0].msgStatusCode + ", Tekstowy opis statusu wiadomości: " +
                          getstatusResult[0].msgStatusDescription + ", Typ wiadomości: " + getstatusResult[0].msgType + ", Liczba części: " + getstatusResult[0].parts +
                          ", Koszt: " + getstatusResult[0].price + ", ID użytkownika: " + getstatusResult[0].extId + ", Czy Unicode?: " + getstatusResult[0].unicode + "\r\n");
 
 */

// Sprawdzanie stanu konta
/*
           // Sprawdzenie aktualnego stanu konta - wywolanie metody GetBalance
           GSMServiceAPI.GetBalanceReturn getbalanceResult = ws.GetBalance(account);

           // Obsluga odpowiedzi z bramki SMS:
           Console.WriteLine("Status żądania: " + getbalanceResult.status + ", Kod błędu: " + getbalanceResult.errCode + ", Opis statusu: " + getbalanceResult.description +
                                ", Stan konta: " + getbalanceResult.balance + ", Waluta konta: " + getbalanceResult.currency + "\r\n");
 
 */

// Anulowanie zaplanowanych wiadomosci
/*
            // Tablica stringów - każdy element zawiera ID jednej zaplanowanej wiadomości, która ma zostać anulowana.
            string[] ids_cancel = new string[] {"1234"};

            // Anulowanie zaplanowanej wiadomości - wywolanie metody Cancel
            GSMServiceAPI.CancelReturn[] getcancelResult = ws.Cancel(account, ids_cancel);

            // Obsluga odpowiedzi z bramki SMS:
            Console.WriteLine("Status żądania: " + getcancelResult[0].status + ", Kod błędu: " + getcancelResult[0].errCode + ", Opis statusu: " + getcancelResult[0].description +
                              ", ID anulowanej wiadomości: " + getcancelResult[0].msgId + ", Nr odbiorcy: " + getcancelResult[0].recipient + "\r\n");
 */
        }
    }
}
