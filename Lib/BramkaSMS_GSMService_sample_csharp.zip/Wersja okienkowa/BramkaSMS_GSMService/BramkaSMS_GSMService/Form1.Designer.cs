﻿namespace BramkaSMS_GSMService
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pass = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.price = new System.Windows.Forms.Button();
            this.send = new System.Windows.Forms.Button();
            this.sandbox = new System.Windows.Forms.CheckBox();
            this.unicode = new System.Windows.Forms.CheckBox();
            this.msg_type = new System.Windows.Forms.ComboBox();
            this.message = new System.Windows.Forms.TextBox();
            this.senderid = new System.Windows.Forms.TextBox();
            this.recipient = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.logBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.msg_id_cancel = new System.Windows.Forms.TextBox();
            this.msg_id_status = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.getStatus = new System.Windows.Forms.Button();
            this.getBalance = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1.SuspendLayout();
            this.Tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pass);
            this.groupBox1.Controls.Add(this.login);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(620, 54);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dane dostępowe do konta";
            // 
            // pass
            // 
            this.pass.Location = new System.Drawing.Point(455, 19);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(100, 20);
            this.pass.TabIndex = 2;
            this.pass.UseSystemPasswordChar = true;
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(226, 19);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(100, 20);
            this.login.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(390, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hasło API:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(164, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login API:";
            // 
            // Tab
            // 
            this.Tab.Controls.Add(this.tabPage1);
            this.Tab.Controls.Add(this.tabPage2);
            this.Tab.Dock = System.Windows.Forms.DockStyle.Top;
            this.Tab.Location = new System.Drawing.Point(0, 54);
            this.Tab.Name = "Tab";
            this.Tab.SelectedIndex = 0;
            this.Tab.Size = new System.Drawing.Size(620, 193);
            this.Tab.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.price);
            this.tabPage1.Controls.Add(this.send);
            this.tabPage1.Controls.Add(this.sandbox);
            this.tabPage1.Controls.Add(this.unicode);
            this.tabPage1.Controls.Add(this.msg_type);
            this.tabPage1.Controls.Add(this.message);
            this.tabPage1.Controls.Add(this.senderid);
            this.tabPage1.Controls.Add(this.recipient);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(612, 167);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SendSMS, GetPrice";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(497, 124);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(92, 23);
            this.price.TabIndex = 7;
            this.price.Text = "Sprawdź cenę";
            this.price.UseVisualStyleBackColor = true;
            this.price.Click += new System.EventHandler(this.price_Click);
            // 
            // send
            // 
            this.send.Location = new System.Drawing.Point(379, 124);
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(75, 23);
            this.send.TabIndex = 6;
            this.send.Text = "Wyślij SMS";
            this.send.UseVisualStyleBackColor = true;
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // sandbox
            // 
            this.sandbox.AutoSize = true;
            this.sandbox.Location = new System.Drawing.Point(379, 84);
            this.sandbox.Name = "sandbox";
            this.sandbox.Size = new System.Drawing.Size(135, 17);
            this.sandbox.TabIndex = 5;
            this.sandbox.Text = "Tryb testowy (sandbox)";
            this.sandbox.UseVisualStyleBackColor = true;
            // 
            // unicode
            // 
            this.unicode.AutoSize = true;
            this.unicode.Location = new System.Drawing.Point(379, 51);
            this.unicode.Name = "unicode";
            this.unicode.Size = new System.Drawing.Size(105, 17);
            this.unicode.TabIndex = 4;
            this.unicode.Text = "Znaki UNICODE";
            this.unicode.UseVisualStyleBackColor = true;
            // 
            // msg_type
            // 
            this.msg_type.Cursor = System.Windows.Forms.Cursors.Default;
            this.msg_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.msg_type.Location = new System.Drawing.Point(468, 11);
            this.msg_type.Name = "msg_type";
            this.msg_type.Size = new System.Drawing.Size(121, 21);
            this.msg_type.TabIndex = 3;
            // 
            // message
            // 
            this.message.Location = new System.Drawing.Point(91, 38);
            this.message.Multiline = true;
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(234, 77);
            this.message.TabIndex = 1;
            // 
            // senderid
            // 
            this.senderid.Location = new System.Drawing.Point(91, 121);
            this.senderid.Name = "senderid";
            this.senderid.Size = new System.Drawing.Size(153, 20);
            this.senderid.TabIndex = 2;
            // 
            // recipient
            // 
            this.recipient.Location = new System.Drawing.Point(91, 12);
            this.recipient.Name = "recipient";
            this.recipient.Size = new System.Drawing.Size(168, 20);
            this.recipient.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Pole nadawcy:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Treść:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(376, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Typ wiadomości:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nr odbiorcy:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(612, 167);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "GetStatus, GetBalance, Cancel";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.getStatus);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.msg_id_status);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(606, 53);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sprawdzanie statusu wiadomości";
            // 
            // logBox
            // 
            this.logBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logBox.Location = new System.Drawing.Point(0, 247);
            this.logBox.Multiline = true;
            this.logBox.Name = "logBox";
            this.logBox.ReadOnly = true;
            this.logBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.logBox.Size = new System.Drawing.Size(620, 97);
            this.logBox.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.getBalance);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(3, 56);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(606, 54);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sprawdzanie stanu konta";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Cancel);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.msg_id_cancel);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(3, 110);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(606, 54);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Anulowanie zaplanowanej wiadomości";
            // 
            // msg_id_cancel
            // 
            this.msg_id_cancel.Location = new System.Drawing.Point(113, 23);
            this.msg_id_cancel.Name = "msg_id_cancel";
            this.msg_id_cancel.Size = new System.Drawing.Size(184, 20);
            this.msg_id_cancel.TabIndex = 0;
            // 
            // msg_id_status
            // 
            this.msg_id_status.Location = new System.Drawing.Point(113, 22);
            this.msg_id_status.Name = "msg_id_status";
            this.msg_id_status.Size = new System.Drawing.Size(184, 20);
            this.msg_id_status.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "ID wiadomości:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "ID wiadomości:";
            // 
            // getStatus
            // 
            this.getStatus.Location = new System.Drawing.Point(342, 18);
            this.getStatus.Name = "getStatus";
            this.getStatus.Size = new System.Drawing.Size(111, 23);
            this.getStatus.TabIndex = 2;
            this.getStatus.Text = "Sprawdź status";
            this.getStatus.UseVisualStyleBackColor = true;
            this.getStatus.Click += new System.EventHandler(this.getStatus_Click);
            // 
            // getBalance
            // 
            this.getBalance.Location = new System.Drawing.Point(177, 19);
            this.getBalance.Name = "getBalance";
            this.getBalance.Size = new System.Drawing.Size(120, 23);
            this.getBalance.TabIndex = 2;
            this.getBalance.Text = "Sprawdź stan konta";
            this.getBalance.UseVisualStyleBackColor = true;
            this.getBalance.Click += new System.EventHandler(this.getBalance_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(342, 21);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(111, 23);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "Anuluj wiadomość";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 344);
            this.Controls.Add(this.logBox);
            this.Controls.Add(this.Tab);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Bramka GSMService.pl - przykład prostej implementacji w C#";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.TextBox login;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl Tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox logBox;
        private System.Windows.Forms.TextBox message;
        private System.Windows.Forms.TextBox senderid;
        private System.Windows.Forms.TextBox recipient;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox msg_type;
        private System.Windows.Forms.CheckBox unicode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button price;
        private System.Windows.Forms.Button send;
        private System.Windows.Forms.CheckBox sandbox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox msg_id_cancel;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button getBalance;
        private System.Windows.Forms.Button getStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox msg_id_status;
        private System.Windows.Forms.ImageList imageList1;


    }
}

